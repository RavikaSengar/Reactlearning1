import React, { memo } from "react";

function ChildA({Learning}){
    console.log("Child Component")
    return(
        <>
        </>
    )
}

export default memo(ChildA);